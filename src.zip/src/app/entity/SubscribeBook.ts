export interface SubscribeBook{
        readerName:string,
        readerEmailId:string,
        subscribedDateTime:Date,
        bookId:number,
        subscriptionId:number
}
