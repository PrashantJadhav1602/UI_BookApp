export interface Book{
    category:string,
    author:string,
    publisher:string,
    price:number

}