export interface Author{
    username:string,
    password:string
}