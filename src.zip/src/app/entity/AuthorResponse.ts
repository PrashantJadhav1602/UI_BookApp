export interface AuthorResponse{
    id:number,
    username:string,
    password:string
}