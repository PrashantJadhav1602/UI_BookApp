export interface BookResponse{
    bookId:number,
    title:string,
    authorId:number,
    category:string,
    publishDate:string,
    publisher:string,
    price:number,
    block:boolean

}