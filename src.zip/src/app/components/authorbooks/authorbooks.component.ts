import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-authorbooks',
  templateUrl: './authorbooks.component.html',
  styleUrls: ['./authorbooks.component.css']
})
export class AuthorbooksComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
